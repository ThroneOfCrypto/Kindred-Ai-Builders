import { DirectorHome } from "../../components/DirectorHome";

export default function DirectorPage() {
  return <DirectorHome />;
}
