import { LoadingScreen } from "../../components/LoadingScreen";

export default function Loading() {
  return <LoadingScreen title="Loading Builder" hint="Preparing project editor..." />;
}
