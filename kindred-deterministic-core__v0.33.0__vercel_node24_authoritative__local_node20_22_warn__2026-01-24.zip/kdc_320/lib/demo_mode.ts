export function isDemoMode() {
  return process.env.NEXT_PUBLIC_KINDRED_DEMO_MODE === "1";
}
