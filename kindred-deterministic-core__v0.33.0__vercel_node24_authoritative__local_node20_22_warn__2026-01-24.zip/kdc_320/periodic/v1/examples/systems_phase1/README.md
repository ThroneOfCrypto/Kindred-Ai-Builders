# Systems examples (Phase 1 index)

Loaded by `periodic.index.phase1.v1.json`.
Contains Phase 0–1 system-of-compounds examples only (membrane + internet_app).
Keeping it separate avoids Phase 1 runs depending on Phase 2+ system fixtures.
