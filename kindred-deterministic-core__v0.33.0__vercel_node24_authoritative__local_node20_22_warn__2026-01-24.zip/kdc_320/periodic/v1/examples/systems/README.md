# Systems examples (full index)

Loaded by `periodic.index.v1.json`.
Contains system-of-compounds examples spanning all domains.

System files with id prefix `system.neg_` are skipped by the checker during positive evaluation.
